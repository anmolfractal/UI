queue()
    .defer(d3.json,"/api/riskdata")
    .await(makeGraphs);

function makeGraphs(error, webService) {
    
    //Clean projectsJson data
    var findata = webService;


    //Create a Crossfilter instance
    var ndx = crossfilter(findata);

var parseDate = d3.time.format.utc("%d/%m/%Y").parse;

var formater = d3.format(",");

findata.forEach(function(d) {
    d.rawDate = d.DateApproved;
    d.DateApproved = parseDate(d.DateApproved);
    d.loanValFormatted = formater(d.LoanValue);
});

    //Define Dimensions
    var loanTypeDim = ndx.dimension(function(d) { return d["LoanType"]; });
    var loanValueDim = ndx.dimension(function(d) { return d["LoanValue"]; });
    var lenderRiskDim = ndx.dimension(function(d) { return d["LenderRisk"]; });
    var riskBin = ndx.dimension(function(d) { return d["RiskGrade"]; });
    var dateDim = ndx.dimension(function(d) { return d["DateApproved"]; });


    var all = ndx.groupAll();
    var minDate = dateDim.bottom(1)[0].DateApproved;
    var maxDate = dateDim.top(1)[0].DateApproved;


    //Calculate Groups
    var loanValueDimGroup = loanTypeDim.group().reduceSum(function (d) {
        return d["LoanValue"];
    });

    var loanSumGroup = loanValueDim.group().reduceSum(function (d) {
        return d["LoanValue"];
    });
    var dateDimCount = dateDim.group();
    var riskBinGroup = riskBin.group();



    var loanTypeBar = dc.barChart("#loan-type-bar-chart", "txnView");
    var loanTime = dc.lineChart("#loan-time-line", "txnView");

    var riskPie = dc.pieChart("#risk-pie-chart", "txnView");
    var dataTableChart = dc.dataTable("#data-table-chart", "txnView");
var loanWidget = dc.numberDisplay("#loan-box", "txnView");

 // tooltips for row chart

            // tooltips for pie chart
            var pieTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" +  d.data.key + "</span> : "  + d3.format(",")(d.data.value) +" Loans"; });

            // tooltips for bar chart
            var barTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" + d.data.key + "</span> : "+"$ "  + d3.format(",")(d.data.value) ; });
         
         var lineTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" + d.data.key + "</span> : " + d3.format(",")(d.data.value) + " Loans" ; });

//bin counter start
    
function bin_counter(group) {
    return {
        value: function() {
            return group.all().filter(function(kv) {
               return kv.value > 0;
            }).length;
        }
    };
}

//bin counter end

   
        loanWidget
            .formatNumber(d3.format(".4s"))
           .valueAccessor(function(x){ return +loanValueDim.groupAll().reduceCount().reduceSum(function(d) { return d.LoanValue; }).value();})
            .group(bin_counter(loanSumGroup));





     loanTypeBar
        .height(220)
        .margins({top: 30, right: 30, bottom: 30, left: 40})
        .transitionDuration(1000)
        .dimension(loanTypeDim)
        .group(loanValueDimGroup)
        .centerBar(false)
        .gap(15)
        .elasticY(true)
        .x(d3.scale.ordinal().domain(loanTypeDim))
        .xUnits(dc.units.ordinal)
        .renderHorizontalGridLines(true)
        .renderVerticalGridLines(true)
        .ordering(function(d){return d.value;})
        .colors(d3.scale.ordinal().domain(["Boat","Car","Line of Credit","Long Term","Mortgage","Small Business"])
                .range(["#5A9BCA","#71A9D2","#89B7DA","#A1C5E2","#A1C5E2","#A1C5E2"]))
        .colorAccessor(function(d) { return d.key;})
        .yAxis().tickFormat(d3.format("s"));


  loanTime
    .height(220)
    .margins({top: 10, right: 60, bottom: 30, left: 40})
    .clipPadding(10)
    .transitionDuration(1000)
    .renderDataPoints({radius: 3, fillOpacity: 0.8, strokeOpacity: 0.8})
    .brushOn(true)
    .dimension(dateDim)
    .group(dateDimCount)
    .elasticY(true)
    .renderHorizontalGridLines(true)
    .renderVerticalGridLines(true)
    .x(d3.time.scale().domain([minDate,maxDate]))
    .yAxis().tickFormat();
    //.xAxis().ticks(12).tickFormat(d3.time.format("%m/%y"));

            
    
          riskPie
            .height(220)
            //.width(350)
            .radius(95)
            .innerRadius(50)
            .transitionDuration(1000)
            .dimension(riskBin)
            .group(riskBinGroup)
            .ordering(function(d){ return -d.key })
            .colors(d3.scale.ordinal().domain(["A","B","C","D","F"])
                    .range(["#b0ce5a","#89B7DA","#A1C5E2","#A1C5E2","#ff0000"]))
            .colorAccessor(function(d) { return d.key;})
            .label(function(d) { return d.key +" (" + d.value.toFixed(1) + ")"; })
            .legend(dc.legend().x(20).y(10).itemHeight(10).gap(4));
    
    
    dataTableChart
        .dimension(loanValueDim)
        .group(function (d) {
                return " ";
            })
        .size(600)
        .columns([
                        function (d) {
                            return d.LoanType;
                        },
                            function (d) {
                            return d.loanValFormatted;
                        },
                        function (d) {
                            return d.RiskGrade;
                        },
                        function (d) {
                            return d.rawDate;
                            }
                     ])
                    
        .sortBy(function (d) {
                                            return d.rawDate;
                                        })
                    
        .order(d3.descending)
        .renderlet(function (table) {
            table.selectAll(".dc-table-group").classed("info", true);
                    });



     dc.renderAll("txnView");
            
/*            function AddXAxis(chartToUpdate, displayText) {
            chartToUpdate.svg()
                .append("text")
                .attr("class", "x-axis-label")
                .attr("text-anchor", "middle")
                .attr("x", chartToUpdate.width()/2)
                .attr("y", chartToUpdate.height())
                .text(displayText);
        }
        AddXAxis(subjectRowChart, "Number of Patients");
       */      

        d3.selectAll(".pie-slice").call(pieTip);
        d3.selectAll(".pie-slice").on('mouseover', pieTip.show)
            .on('mouseout', pieTip.hide);

        d3.selectAll(".bar").call(barTip);
        d3.selectAll(".bar").on('mouseover', barTip.show)
            .on('mouseout', barTip.hide);  

        d3.selectAll(".dot").call(lineTip);
        d3.selectAll(".dot").on('mouseover', lineTip.show)
            .on('mouseout', lineTip.hide); 

};
