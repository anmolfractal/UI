queue()
    .defer(d3.json,"/api/loyalty")
    .await(makeGraphs);

function makeGraphs(error, webService) {
    
    //Clean projectsJson data
    var findata = webService;


    //Create a Crossfilter instance
    var ndx = crossfilter(findata);

    //Define Dimensions
    var userIDDim = ndx.dimension(function(d) { return d["UserID"]; });
    var loyaltyStatusDim = ndx.dimension(function(d) { return d["LoyaltyStatus"]; });
    var annualIncomeDim = ndx.dimension(function(d) { return d["AnnualIncome"]; });
    var accountTypeDim = ndx.dimension(function(d) { return d["AccountType"]; });
    var loanValueDim = ndx.dimension(function(d) { return d["LoanValue"]; });
    var loanTypeDim = ndx.dimension(function(d) { return d["LoanType"]; });
    var transactionTypeDim = ndx.dimension(function(d) { return d["TransactionType"]; });
    var transactionVolumeDim = ndx.dimension(function(d) { return d["TransactionVolume"]; });
    var transactionVolumeBinDim = ndx.dimension(function(d) { return d["TransactionVolumeBin"]; });



    var all = ndx.groupAll();
    
    //Calculate Groups
var transactionTypeDimGroup = transactionTypeDim.group();
var transactionVolumeBinDimGroup = transactionVolumeBinDim.group();
   var txnVolumeSumGroup = loyaltyStatusDim.group().reduceSum(function (d) {
        return d["LoanValue"];
    });




    //Charts

    var txnTypeChart = dc.pieChart("#txn-type-pie", "subjectView");
    var txnVolumeChart = dc.rowChart("#txn-volume-pie", "subjectView");
//    var loanLoyaltyChart = dc.barChart("#loan-loyalty-chart", "subjectView");
    var boxChart = dc.boxPlot("#box-plot-chart", "subjectView");
 

 
            // tooltips for pie chart
            var pieTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" +  d.data.key + "</span> : "  + d.data.value; });

            // tooltips for bar chart
            var rowTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" +  d.key + "</span> : "  + d.value; });
         
    



//bin counter start
    
/*function bin_counter(group) {
    return {
        value: function() {
            return group.all().filter(function(kv) {
               return kv.value > 0;
            }).length;
        }
    };
}
*/
//bin counter end
var txnVolumeSumGroup2 = loyaltyStatusDim.group().reduce(
        function(p,v) {
          p.push(v.TransactionVolume);
          return p;
        },
        function(p,v) {
          p.splice(p.indexOf(v.TransactionVolume), 1);
          return p;
        },
        function() {
          return [];
        }
      );


   
        boxChart
        //.width(768)
        .height(524)
        .clipPadding(20)
        .margins({top: 10, right: 30, bottom: 30, left: 40})
        .dimension(loyaltyStatusDim)
        .group(txnVolumeSumGroup2)
        .x(d3.scale.ordinal().domain(loyaltyStatusDim))
   .xUnits(dc.units.ordinal)
               .renderHorizontalGridLines(true)
            .renderVerticalGridLines(true)
            .ordinalColors(["#CD7F32","#ffd700","#E5E4E2","#C0C0C0"])
        .elasticY(true)
          .yAxisLabel("Account Value")
         .yAxis().tickFormat(d3.format("s"));





         txnTypeChart
            .height(220)
            //.width(350)
            .radius(90)
            .innerRadius(50)
            .transitionDuration(1000)
            .dimension(transactionTypeDim)
            .group(transactionTypeDimGroup)
            //.ordinalColors(["#3E94EF","#2bbf9f"])
           // .label(function(d) { return d.key ; })
            .label(function(d) { return d.key +" (" + d.value.toFixed(0) + ")"; })
            .legend(dc.legend().x(10).y(10).itemHeight(10).gap(5));

        txnVolumeChart
            .height(220)
            .margins({top: 10, right: 30, bottom: 30, left: 20})
            .transitionDuration(1000)
            .dimension(transactionVolumeBinDim)
            .gap(5)
            .group(transactionVolumeBinDimGroup)
            //.ordinalColors(["#eb5768","#2bbf9f","#3E94EF"])
            .ordering(function(d) { return -d.value })
            .label(function(d){
                return d.key  +"-"+ d.value  ;
            })
            .elasticX(true)
            .xAxis().ticks(8);
        

   
            dc.renderAll("subjectView");
            
     

        d3.selectAll(".pie-slice").call(pieTip);
        d3.selectAll(".pie-slice").on('mouseover', pieTip.show)
            .on('mouseout', pieTip.hide);

        d3.selectAll("g.row").call(rowTip);
        d3.selectAll("g.row").on('mouseover', rowTip.show)
            .on('mouseout', rowTip.hide);



};
