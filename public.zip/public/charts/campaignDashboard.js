queue()
    .defer(d3.json,"/api/campaign")
    .await(makeGraphs);

function makeGraphs(error, webService) {
    
    //Clean projectsJson data
    var findata = webService;



    //Create a Crossfilter instance
    var ndx = crossfilter(findata);

    //Define Dimensions
    var campaignDim = ndx.dimension(function(d) { return d["Campaign"]; });
    var dailySpendDim = ndx.dimension(function(d) { return d["Daily Spend"]; });
    var interestsDim = ndx.dimension(function(d) { return d["Interest Group"]; });
    var ageDim = ndx.dimension(function(d) { return d["Age Demographic"]; });
    var likesDim = ndx.dimension(function(d) { return d["Likes"]; });
    var spendToDateDim = ndx.dimension(function(d) { return d["Spend to Date"]; });
    var genderDim = ndx.dimension(function(d) { return d["Gender"]; });



    var all = ndx.groupAll();

var genderDimGroup = genderDim.group();
var ageDimGroup = ageDim.group();

    var likesGroup = campaignDim.group().reduceSum(function (d) {
        return d["Likes"];
    });
    var spendToDateGroup = campaignDim.group().reduceSum(function (d) {
        return d["Spend to Date"];
    });



    //Charts
    var spendLineChart = dc.barChart("#spend-line-chart", "subjectView");
    var genderCampPie = dc.pieChart("#camp-gender-pie", "subjectView");
    var ageCampPie = dc.pieChart("#camp-age-pie", "subjectView");
    var dataTableCamp = dc.dataTable("#data-table-chart-camp", "subjectView");
 //var chartTest = dc.compositeChart("#test-chart","subjectView");


//bin counter start
    
/*function bin_counter(group) {
    return {
        value: function() {
            return group.all().filter(function(kv) {
               return kv.value > 0;
            }).length;
        }
    };
}*/

//bin counter end
//var mark1Group = dateDim.group().reduceSum(function (d) { return d.Likes; });
//var mark2Group = dateDim.group().reduceSum(function (d) { return d.Spend; });
 
/*    chartTest
        .height(480)
        .x(d3.scale.ordinal().domain(campaignDim))
        //.xUnits(dc.units.ordinal)
        .yAxisLabel("The Y Axis")
        .legend(dc.legend().x(80).y(20).itemHeight(13).gap(5))
        .renderHorizontalGridLines(true)
        .compose([
            dc.lineChart(chartTest)
                .dimension(campaignDim)
                .colors('red')
                .group(likesGroup, "Top Line")
                .dashStyle([2,2]),
            dc.lineChart(chartTest)
                .dimension(campaignDim)
                .colors('blue')
                .group(spendToDateGroup, "Bottom Line")
                .dashStyle([5,5])
            ])
        .brushOn(false)
        .render();
*/












/*        .height(300)
        .transitionDuration(1000)
        .margins({top: 30, right: 50, bottom: 25, left: 60})
        .dimension(campaignDim)
        .mouseZoomable(true)
        .x(d3.scale.ordinal().domain(campaignDim))
        .xUnits(dc.units.ordinal)
        .elasticY(true)
        .renderHorizontalGridLines(true)
        .legend(dc.legend().x(70).y(10).itemHeight(13).gap(5))
        .brushOn(false)
        .compose([
                    dc.lineChart(chartTest)
                            .group(likesGroup, "Likes")
                            .valueAccessor(function (d) {
                                return d.value;
                            }),
                    dc.lineChart(chartTest)
                            .group(spendToDateGroup, "Spend to date")
                            .valueAccessor(function (d) {
                                return d.value;
                            })
                            .ordinalColors(["orange"])
                            .useRightYAxis(true)
                ])
                .yAxisLabel("Likes")
                .rightYAxisLabel("Spend to date")
                .renderHorizontalGridLines(true);*/





            // tooltips for pie chart
            var pieTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" +  d.data.key + "</span> : "  + d.data.value + " Customers"; });

            // tooltips for bar chart
            var barTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" + d.data.key + "</span> : " + d.data.value ; });



        spendLineChart
            .margins({top: 20, right: 20, bottom: 60, left: 50})
            .height(220)
            .clipPadding(10)
            .transitionDuration(1000)
            .dimension(campaignDim)
            .group(likesGroup,"Likes")
            .stack(spendToDateGroup,"Spend to Date")
            .centerBar(false)
            .gap(15)
            .elasticY(true)
            .renderHorizontalGridLines(true)
            .renderVerticalGridLines(true)
            .x(d3.scale.ordinal().domain(campaignDim))
            .xUnits(dc.units.ordinal)
            .legend(dc.legend().x(60).y(10).itemHeight(10).gap(5));

    
        genderCampPie
            .height(220)
            //.width(350)
            .radius(105)
            //.innerRadius(70)
            .transitionDuration(1000)
            .dimension(genderDim)
            .group(genderDimGroup)
            //.ordinalColors(["#3E94EF","#2bbf9f"])
            .label(function(d) { return d.key +" (" + d.value.toFixed(0) + ")"; })
            .legend(dc.legend().x(5).y(10).itemHeight(10).gap(5));

        ageCampPie
            .height(220)
            //.width(350)
            .radius(105)
            .innerRadius(50)
            .transitionDuration(1000)
            .dimension(ageDim)
            .group(ageDimGroup)
            .ordering(function(d){ return -d.key })
            //.ordinalColors(["#3E94EF","#2bbf9f"])
            .label(function(d) { return d.key +" (" + d.value.toFixed(0) + ")"; })
            .legend(dc.legend().x(10).y(10).itemHeight(10).gap(5));


   dataTableCamp
        .dimension(campaignDim)
        .group(function (d) {
                return " ";
            })
        .size(500)
        .columns([
                        function (d) {
                            return d.Campaign;
                        },
                            function (d) {
                            return d["Interest Group"];
                        },
                        function (d) {
                            return d["Spend to Date"];
                        },
                        function (d) {
                            return d.Likes;
                            }
                     ])
                    
        .sortBy(function (d) {
                                            return d["Spend to Date"];
                                        })
                    
        .order(d3.descending)
        .renderlet(function (table) {
            table.selectAll(".dc-table-group").classed("info", true);
                    });

 


            dc.renderAll("subjectView");

        d3.selectAll(".pie-slice").call(pieTip);
        d3.selectAll(".pie-slice").on('mouseover', pieTip.show)
            .on('mouseout', pieTip.hide);

        d3.selectAll(".bar").call(barTip);
        d3.selectAll(".bar").on('mouseover', barTip.show)
            .on('mouseout', barTip.hide);
// rotate the x Axis labels

        spendLineChart.selectAll("g.x text")
            .attr("class", "campusLabel")
            .style("text-anchor", "end") 
            .attr("transform", "translate(-10,0)rotate(315)");


};
