queue()
    .defer(d3.json,"/api/data")
    .await(makeGraphs);

function makeGraphs(error, webService) {
    
    //Clean projectsJson data
    var findata = webService;


    //Create a Crossfilter instance
    var ndx = crossfilter(findata);

    //Define Dimensions
    var interfaceDim = ndx.dimension(function(d) { return d["InterfaceType"]; });
    var txnTypeDim = ndx.dimension(function(d) { return d["TransactionType"]; });
    var txnValueDim = ndx.dimension(function(d) { return d["TransactionValue"]; });
    var txnValBinDim = ndx.dimension(function(d) { return d["TransactionValueBin"]; });
    var accountTypeDim = ndx.dimension(function(d) { return d["AccountType"]; });
    var expenseTypeDim = ndx.dimension(function(d) { return d["ExpenseType"]; });
    var ageDim = ndx.dimension(function(d) { return d["Age"]; });
    var ageBinDim = ndx.dimension(function(d) { return d["AgeBin"]; });
    var genderDim = ndx.dimension(function(d) { return d["Gender"]; });

    var annualIncomeDim = ndx.dimension(function(d) { return d["AnnualIncome"]; });
    var annualIncomeBinDim = ndx.dimension(function(d) { return d["AnnualIncomeBin"]; });
    var maritalStatusDim = ndx.dimension(function(d) { return d["MaritalStatus"]; });


    var all = ndx.groupAll();


    var interfaceDimGroup = interfaceDim.group();
    var txnTypeDimGroup = txnTypeDim.group();
    var txnValBinDimGroup = txnValBinDim.group();
    var annualIncomeBinDimGroup = annualIncomeBinDim.group();
    var genderDimGroup = genderDim.group();
    var ageBinDimGroup = ageBinDim.group();

/*    var prodGroup = customerName.group().reduceSum(function (d) {
        return d["Products Per Customer"];
    });
    var holdGroup = customerName.group().reduceSum(function (d) {
        return d["Holdings"];
    });
*/


    //Charts
    var interfaceChart = dc.rowChart("#interface-row", "subjectView");
    var transactionTypeChart = dc.pieChart("#transaction-pie", "subjectView");
    var txnValPie = dc.pieChart("#txn-val-segment-pie", "subjectView");
    var incomePieSegment = dc.pieChart("#income-pie-segment", "subjectView");
    var genderBarChart = dc.barChart("#gender-bar", "subjectView");
   var ageSegmentChart = dc.pieChart("#age-segment-pie", "subjectView");
/*
    var numberChart1 = dc.numberDisplay("#number-box1", "subjectView");

    var numberChart2 = dc.numberDisplay("#number-box2", "subjectView");
    var numberChart3 = dc.numberDisplay("#number-box3", "subjectView");
    var numberChart4 = dc.numberDisplay("#number-box4", "subjectView");
    var segmentRowChart = dc.rowChart("#segment-row-chart", "subjectView");
    var custProdHoldChart = dc.barChart("#cust-bar-chart", "subjectView");
*/

// tooltips for row chart
            var rowTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" +  d.key + "</span> : "  + d.value; });

            // tooltips for pie chart
            var pieTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" +  d.data.key + "</span> : "  + d.data.value + " Customers"; });

            // tooltips for bar chart
            var barTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" + d.data.key + "</span> : " + d.data.value ; });
         


/*//average calculation start


*/
         interfaceChart
            //.width(350)
            .height(220)
            .margins({top: 10, right: 40, bottom: 30, left: 20})
            .transitionDuration(1000)
            .dimension(interfaceDim)
            .gap(10)
            .group(interfaceDimGroup)
            //.ordinalColors(["#a8cf38","#c12026","#00aef5","#8781bd","#fbaf5d"])
            .ordering(function(d) { return -d.key })
            .label(function(d){
                return d.key + " : " + d.value ;
            })
            .elasticX(true)
            .xAxis().ticks(8);

      
    
        transactionTypeChart
            .height(220)
            //.width(350)
            .radius(90)
            .innerRadius(50)
            .transitionDuration(1000)
            .dimension(txnTypeDim)
            .group(txnTypeDimGroup)
            //.ordinalColors(["#3E94EF","#2bbf9f"])
            .label(function(d) { return d.key +" (" + d.value.toFixed(0) + ")"; })
            .legend(dc.legend().x(5).y(10).itemHeight(10).gap(5));

        txnValPie
            .height(220)
            //.width(350)
            .radius(90)
            .innerRadius(50)
            .transitionDuration(1000)
            .dimension(txnValBinDim)
            .group(txnValBinDimGroup)
            .ordering(function(d){ return -d.value })
            //.ordinalColors(["#3E94EF","#2bbf9f"])
            .label(function(d) { return "$" + d.key +" (" + d.value.toFixed(0) + ")"; })
            .legend(dc.legend().x(5).y(10).itemHeight(10).gap(5));

        ageSegmentChart
            .height(220)
            //.width(350)
            .radius(90)
           // .innerRadius(10)
            .transitionDuration(1000)
            .dimension(ageBinDim)
            .group(ageBinDimGroup)
            .ordering(function(d){ return -d.key })
            //.ordinalColors(["#3E94EF","#2bbf9f"])
            .label(function(d) { return d.key ; })
//            .label(function(d) { return d.key +" (" + d.value.toFixed(1) + ")"; })
            .legend(dc.legend().x(5).y(10).itemHeight(10).gap(5));

        incomePieSegment
            .height(220)
            //.width(350)
            .radius(95)
            .innerRadius(50)
            .transitionDuration(1000)
            .dimension(annualIncomeBinDim)
            .group(annualIncomeBinDimGroup)
            .ordering(function(d){ return -d.value })
            //.ordinalColors(["#3E94EF","#2bbf9f"])
            .label(function(d) { return "$ "+d.key ; })
            .legend(dc.legend().x(5).y(10).itemHeight(10).gap(5));

        genderBarChart
            .height(220)
            .margins({top: 10, right: 30, bottom: 20, left: 30})
            .transitionDuration(1000)
            .dimension(genderDim)
            .group(genderDimGroup)
            .centerBar(false)
            .gap(25)
            .elasticY(true)
            .x(d3.scale.ordinal().domain(genderDim))
            .xUnits(dc.units.ordinal)
            .renderHorizontalGridLines(true)
            .renderVerticalGridLines(true)
            .ordering(function(d){return d.value;})
            .colors(d3.scale.ordinal().domain(["Male","Female"]).range(["#00aeef","#f49ac1"]))
            .colorAccessor(function(d) { return d.key;})
                    .renderlet(function(genderBarChart) {
        var barsData = [];
        var bars = genderBarChart.selectAll('.bar').each(function (d) {
        barsData.push(d);
        });

    //Remove old values (if found)
    d3.select(bars[0][0].parentNode).select('#inline-labels').remove();
    //Create group for labels 
    var gLabels = d3.select(bars[0][0].parentNode).append('g').attr('id', 'inline-labels');
    for (var i = bars[0].length - 1; i >= 0; i--) {

        var b = bars[0][i];
        //Only create label if bar height is tall enough
        if (+b.getAttribute('height') < 10) continue;

        gLabels.append("text")
            .text(barsData[i].data.value)
            .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
            .attr('y', +b.getAttribute('y') + 15)
            .attr('text-anchor', 'middle')
            .attr('fill', 'white');
              }

                })
            .yAxis().tickFormat(d3.format("s"));



            dc.renderAll("subjectView");

            
/*            function AddXAxis(chartToUpdate, displayText) {
            chartToUpdate.svg()
                .append("text")
                .attr("class", "x-axis-label")
                .attr("text-anchor", "middle")
                .attr("x", chartToUpdate.width()/2)
                .attr("y", chartToUpdate.height())
                .text(displayText);
        }
        AddXAxis(subjectRowChart, "Number of Patients");
       */      
        d3.selectAll("g.row").call(rowTip);
        d3.selectAll("g.row").on('mouseover', rowTip.show)
            .on('mouseout', rowTip.hide);

        d3.selectAll(".pie-slice").call(pieTip);
        d3.selectAll(".pie-slice").on('mouseover', pieTip.show)
            .on('mouseout', pieTip.hide);

        d3.selectAll(".bar").call(barTip);
        d3.selectAll(".bar").on('mouseover', barTip.show)
            .on('mouseout', barTip.hide);
// rotate the x Axis labels
/*
        custProdHoldChart.selectAll("g.x text")
            .attr("class", "campusLabel")
            .style("text-anchor", "end") 
            .attr("transform", "translate(-10,0)rotate(315)");
*/

};
