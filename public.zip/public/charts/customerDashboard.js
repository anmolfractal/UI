// Create Global Variables
var txnAccountRow = dc.rowChart("#txnaccount-row", "mapView");
var expenseDistRow = dc.rowChart("#expense-row", "mapView");
var txnBinPie = dc.pieChart("#txnbin-pie", "mapView");
var dataTableChart = dc.dataTable("#data-table", "mapView");

var dataset;
var cScale;
var rScale;
// Load csv file
var formater = d3.format(",");
d3.json("/api/customer", function(data) {
    // Format columns
    data.forEach(function(e) {
        // convert from string to int
        e.Latitude = +e.Latitude;
        e.Longitude = +e.Longitude;
        e.txnValue = formater(e.TransactionValue);

    });
    dataset = data;
    // create scales
    scales(dataset);
    // create markers
    update_markers(dataset);
    // create charts
    charts(dataset);
});
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
///////////// MAP SECTION /////////////////////////
// initialize map
var map = L.map("map-container", "mapView").setView([24.45, 54.48], 11);//latitude, longitude, zoom level
map.dragging.disable();
/*
.locate({
    "setView" : false
});*/

// if true, as soon as the user agrees to share its location and itâ€™s detected by the browser, the map will set the view to it
// Add a tile layer
var layer = new L.TileLayer("http://{s}.tile.osm.org/{z}/{x}/{y}.png", {
    maxZoom : 11,
    minZoom : 10
});
// Add layer to map
map.addLayer(layer);
// Initialize the SVG layer
map._initPathRoot();
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
///////////// SVG SECTION /////////////////////////
// We pick up the SVG from the map object
var svg = d3.select("#map-container").select("svg").append("g");
// markers pointer
var markers = svg.selectAll("circle");
// Define 'div' for tooltips
var div = d3.select("body").append("div")// declare the tooltip div
.attr("class", "tooltip")// apply the 'tooltip' class
.style("opacity", 0)// set the opacity to nil
.style("top", "15px")// make sure div is out of the way
//.style("left", "0px");
.style("right", "10px");
// make sure div is out of the way
function scales(data) {
    // Create color scale
    cScale = d3.scale.linear().domain([d3.min(data, function(d) {
        return d.TransactionValue;
    }), d3.max(data, function(d) {
        return d.TransactionValue;
    })]).range(["green", "green"]);
    // Create radius scale
    rScale = d3.scale.linear().domain([d3.min(data, function(d) {
        return d.TransactionValue;
    }), d3.max(data, function(d) {
        return d.TransactionValue;
    })]).range([5, 15]);
};
// Here is where the markers are updated
function update_markers(data) {
    // update
    markers = markers.data(data).style("stroke", "black").style("opacity", .6)
    //.style("fill", "red")
    .style("fill", function(d) {
        return cScale(d.TransactionValue);
    }).attr("r", function(d) {
        return rScale(d.TransactionValue);
    });
    // enter
    markers
    //.style("fill", "green")
    .enter().append("circle").style("stroke", "black").style("opacity", .6)
    //.style("fill", "green")
    .style("fill", function(d) {
        return cScale(d.TransactionValue);
    }).attr("r", function(d) {
        return rScale(d.TransactionValue);
    });
    // exit
    markers.exit()
    //.style("fill", "yellow")
    .remove();
    // call update function
    update();
    // show tooltip on hover
    // style of div is in the template.html file
    var popup = markers.on("mouseenter", function(d) {
        //div.transition().duration(500).style("opacity", 0);
        div.transition().duration(200).style("opacity", .9);
        div.html(
        // The first <a> tag
        '<strong style="color:#00BFFF;">' + "Date : " + d.ExpenseDate + '</strong>' +
        // closing </a> tag
        "<br>" + "<p>POS: " + d["POS Location"] + "<br>" + "Txn Val: " + d.TransactionValue +"$" + "</p>").style("left", (d3.event.pageX) + "px").style("top", (d3.event.pageY - 80) + "px");
    });
    
    var popup = markers.on("mouseleave", function(d) {
        div.transition().duration(500).style("opacity", 0);
        //div.transition().duration(200).style("opacity", .9);
        div.html(
        // The first <a> tag
        '<strong style="color:#00BFFF;">' + "Date : " + d.ExpenseDate + '</strong>' +
        // closing </a> tag
        "<br>" + "<p>POS: " + d["POS Location"] + "<br>" + "Txn Val: " + d.TransactionValue +"$"+ "</p>").style("left", (d3.event.pageX) + "px").style("top", (d3.event.pageY - 80) + "px");
    });
};// end update_markers function
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
///////////// CHARTS SECTION /////////////////////////
// Create function
function charts(data) {
    // Make a crossfilter object
    var ndx = crossfilter(data);
    //console.log(data);
    //define a dimension
    //Here we will group by type
    userIDDIM = ndx.dimension(function(d) { return d.UserID;});
    txnValueDim = ndx.dimension(function(d) { return d.TransactionValue;});
    accountTypeDim = ndx.dimension(function(d) { return d.AccountType;});
    POSLocationDim = ndx.dimension(function(d) { return d["POS Location"];});
    txnValueBinDim = ndx.dimension(function(d) { return d.TransactionValueBin;});
    expenseTypeDim = ndx.dimension(function(d) { return d.ExpenseType;});
    ageDim = ndx.dimension(function(d) { return d.Age;});
    maritalStatusDIm = ndx.dimension(function(d) { return d.MaritalStatus;});
    loyaltyDim = ndx.dimension(function(d) { return d.LoyaltyMember;});
    loyaltyStatusDim = ndx.dimension(function(d) { return d.LoyaltyStatus;});
    loyaltyDim = ndx.dimension(function(d) { return d.LoyaltyMember;});
    incomeDim = ndx.dimension(function(d) { return d.AnnualIncome;});


/*    dim = ndx.dimension(function(d) {
        return d.Segment;
    });
    dim2 = ndx.dimension(function(d) {
        return d.Type;
    });*/


accountTypeDimGroup = accountTypeDim.group();
txnValueBinDimGroup = txnValueBinDim.group();

accountTypeDimGroup2 = accountTypeDim.group().reduceSum(function(d) {
        return d.TransactionValue;
    });

expenseTypeDimGroup2 = expenseTypeDim.group().reduceSum(function(d) {
        return d.TransactionValue;
    });

var loyalPrint = loyaltyStatusDim.bottom(1)[0].LoyaltyStatus;
//var userIDPrint = userIDDIM.bottom(1)[0].UserID;


document.getElementById("LoyaltyBox1").innerHTML = "<strong> Loyalty Status </strong>"+ " : "+ loyalPrint;
//document.getElementById("UserBox").innerHTML = "User ID " +"- "+ userIDPrint;




/*     selectField = dc.selectMenu('#menuselect')
        .dimension(dim2)
        .group(g2)
        .on("filtered", onFilt);*/

    //g2 = dim2.group().reduceSum(function(d) {return d.riskIndicator});
    // dummy dimensions to filter on map changes
    lonDim = ndx.dimension(function(d) {
        return d.Longitude;
    });
    latDim = ndx.dimension(function(d) {
        return d.Latitude;
    });

// tooltips for row chart
            var rowTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" +  d.key + "</span> : " + " $ " + d.value ; });



            // tooltips for pie chart
            var pieTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" +  d.data.key + "</span> : " + " $ " + d.data.value + " Transactions"; });



    //Lets create a row chart
    txnAccountRow
        .height(200)
        .margins({top: 10, right: 180, bottom: 30, left: 10})
        .dimension(accountTypeDim)
        .group(accountTypeDimGroup2)
        .ordinalColors(["#a8cf38","#c12026","#00aef5","#8781bd","#fbaf5d"])
        .gap(10)
        .transitionDuration(1000)
        .margins({top: 10, right: 50, bottom: 30, left: 20})
         .on("filtered", onFilt)
            .label(function(d){
                return d.key + " : " + " $ "+  d3.format(",")(d.value);
            })
        .elasticX(true)
        .xAxis().ticks(7).tickFormat(d3.format("s"));
    //Lets create a row chart
    expenseDistRow
        //.width(400)
        .height(200)
        .margins({top: 10, right: 180, bottom: 30, left: 10})
        .dimension(expenseTypeDim)
        .group(expenseTypeDimGroup2)
        .ordinalColors(["#a8cf38","#c12026","#00aef5","#8781bd","#fbaf5d"])
        .gap(10)
        .transitionDuration(1000)
        .margins({top: 10, right: 50, bottom: 30, left: 20})
         .on("filtered", onFilt)
            .label(function(d){
                return d.key + " : " + " $ "+  d3.format(",")(d.value);
            })
        .elasticX(true)
        .xAxis().ticks(7).tickFormat(d3.format("s"));
       
    txnBinPie
        .height(200)
            //.width(350)
        .radius(80)
        .innerRadius(40)
        .transitionDuration(1000)
        .dimension(txnValueBinDim)
        .group(txnValueBinDimGroup)
        .on("filtered", onFilt)
        .ordinalColors(["#a8cf38","#c12026","#00aef5","#9F9ACA"])
        .label(function(d) { return "$ "+ d.key +" (" + d.value.toFixed(0) + ")"; })
        .legend(dc.legend().x(2).y(10).itemHeight(8).gap(5));


    dataTableChart
        .dimension(userIDDIM)
        .group(function (d) {
                return " ";
            })
        .size(697)
        .columns([
                        function (d) {
                            return d.UserID;
                        },
                            function (d) {
                            return d.txnValue;
                        },
                        function (d) {
                            return d["AccountType"];
                        },
                        function (d) {
                            return d["POS Location"];
                            },
                        function (d) {
                            return d["ExpenseType"];
                        },
                        function (d) {
                            return d["ExpenseDate"];
                        }
                     ])
                    
        .sortBy(function (d) {
                                            return d.ExpenseDate;
                                        })
                    
        .order(d3.descending)
        .renderlet(function (table) {
            table.selectAll(".dc-table-group").classed("info", true);
                    });







    dc.renderAll("mapView");

          d3.selectAll("g.row").call(rowTip);
        d3.selectAll("g.row").on('mouseover', rowTip.show)
            .on('mouseout', rowTip.hide);


        d3.selectAll(".pie-slice").call(pieTip);
        d3.selectAll(".pie-slice").on('mouseover', pieTip.show)
            .on('mouseout', pieTip.hide);


    // render all charts on the page
};// end charts function
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
///////////// ARC SECTION /////////////////////////
// globals
var pi = Math.PI;
var width = 200;
var height = 200;
// where the arc will live
var ARC_div = d3.select("body").select("#cleartxt");
// Appending SVG to ARC_div
var ARC_svg = ARC_div.append("svg").attr("width", width).attr("height", height);
// Arc values - inner + outer radius (circle size), start angle (0 = top of circle).
var arc = d3.svg.arc().innerRadius(90).outerRadius(92).startAngle(0);
// endAngle appended to background and foreground paths.
// location of arc
var circleOne = ARC_svg.append("g").attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");
// Appending the background endAngle path to show full circle
circleOne.append("path").attr("d", arc.endAngle(2 * pi)).style("fill", "#7f8c8d");
// Appending percentage text
circleOne.append("text").attr("text-anchor", "middle").attr("transform", "translate(0" + "," + "25)").attr("opacity", 0.3).text("Reset");
// light up on hover
circleOne.select("text").on("mouseover", function(d) {
    circleOne.select("text").attr("opacity", 1);
    circleOne.select("path").style("fill", "red");
});
// dim on mouseout
circleOne.select("text").on("mouseout", function(d) {
    circleOne.select("text").attr("opacity", 0.3);
    circleOne.select("path").style("fill", "#7f8c8d");
});
// reset charts on click event
circleOne.on("click", function(d) {
    RowChart.filterAll();
    RowChart2.filterAll();
    dc.redrawAll("mapView");
});
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
///////////// MISC SECTION /////////////////////////
// the update function to ensures that whenever the leaflet layer moves, the SVG layer with the d3.js elements follows
function update() {
    markers.attr("transform", function(d) {
        return "translate(" + map.latLngToLayerPoint([d.Latitude, d.Longitude]).x + "," + map.latLngToLayerPoint([d.Latitude, d.Longitude]).y + ")";
    })
};

$('.reset1').on('click', function() {
    alert('k')
   $("map-container").setView([24.45, 54.48], 11);
});
// hide pop-up div element
/*
$(".tooltip").on('click', function() {
    $(".tooltip").css('opacity', 0);
    $(".tooltip").css("top", "150px")// make sure div is out of the way
    $(".tooltip").css("left", "0px");
    // make sure div is out of the way
});*/
 
// update on pan zoom
function update_on_change() {
    // get lat lon values of current scope
    var bounds = map.getBounds();
    var northEast = bounds.getNorthEast();
    var southWest = bounds.getSouthWest();
    // filter charts with dummy dimensions
    lonDim.filterRange([southWest.lng, northEast.lng]);
    latDim.filterRange([southWest.lat, northEast.lat]);
    // update charts
    dc.redrawAll("mapView");
    //update markers
    update_markers(lonDim.top(Infinity));
};
// capture map changes
map.on('moveend', function(e) {
    update_on_change();
});
// Called when dc.js is filtered (typically from user click interaction)
var onFilt = function(chart, filter) {
    // add new markers with filtered data
    update_markers(accountTypeDim.top(Infinity));
}; 
