queue()
    .defer(d3.csv,"/datanew/budget.csv")
    .defer(d3.csv,"/data/einvoice.csv")
    .defer(d3.csv,"/data/cashflow.csv")
    .await(makeGraphs);

function makeGraphs(error, budgetdat, einvoicedat, cashflowdat) {
    
    //Clean projectsJson data
    var budgetData = budgetdat;
    var einvoiceData = einvoicedat;
    var cashflowData = cashflowdat;

	console.log(cashflowData);

    //Create a Crossfilter instance
    var ndx = crossfilter(budgetData);
    var ndx1 = crossfilter(einvoiceData);
    var ndx2 = crossfilter(cashflowData);
    //Define Dimensions
//budget dims
var deptDim = ndx.dimension(function(d) { return d["Dept"]; });
var type1Dim = ndx.dimension(function(d) { return d["Type"]; });
var month1Dim = ndx.dimension(function(d) { return d["Month"]; });
var expense1Dim = ndx.dimension(function(d) { return d["Expenses"]; });
//var avgDim = ndx.dimension(function(d) { return d["Average"]; });
var salaryDim = ndx.dimension(function(d) { return d["Salaries"]; });
var all = ndx.groupAll();
var deptGroup = deptDim.group().reduceSum(function (d) {		
        return d["Expenses"];
    });

var monthAvgGroup = month1Dim.group().reduceSum(function (d) {
        return d["Expenses"];
    });

var monthSalGroup = month1Dim.group().reduceSum(function (d) {
        return d["Salaries"];
    });

var monthActualExpenseGroup = type1Dim.group().reduceSum(function (d) {
        return d["Actual"];
    });

var monthPlanExpenseGroup = type1Dim.group().reduceSum(function (d) {
        return d["Plan"];
    });


    //einvoice dims
    var compDim = ndx1.dimension(function(d) { return d["Company"]; });
    var daysoutDim = ndx1.dimension(function(d) { return d["Days Out"]; });
    var amountDim = ndx1.dimension(function(d) { return d["Amount"]; });
   
    var all1 = ndx1.groupAll();

var compGroup = compDim.group().reduceSum(function (d) {
        return d["Amount"];
    });

var daysGroup = daysoutDim.group().reduceSum(function (d) {
        return d["Amount"];
    });    



//chart stack cashflow

    var monthDim = ndx2.dimension(function(d) { return d["Month"]; });
    var typeDim = ndx2.dimension(function(d) { return d["Type"]; });
    var revenueDim = ndx2.dimension(function(d) { return d["Revenue"]; });
    var expenseDim = ndx2.dimension(function(d) { return d["Expense"]; });
    var cashDim = ndx2.dimension(function(d) { return d["Cash"]; });


 var all2 = ndx2.groupAll();
var revenueGroup = monthDim.group().reduceSum(function (d) {
        return d["Revenue"];
    });

var expenseGroup = monthDim.group().reduceSum(function (d) {
        return d["Expense"];
    });    
var cashGroup = monthDim.group().reduceSum(function (d) {
        return d["Cash"];
    }); 

/*    var prodGroup = customerName.group().reduceSum(function (d) {
        return d["Products Per Customer"];
    });
    var holdGroup = customerName.group().reduceSum(function (d) {
        return d["Holdings"];
    });
*/


    //Charts
    var chart1 = dc.rowChart("#dept-row", "subjectView3");
        var chart2 = dc.compositeChart("#multi-composite", "subjectView3");
 /*   var transactionTypeChart = dc.pieChart("#transaction-pie", "subjectView");
    var txnValPie = dc.pieChart("#txn-val-segment-pie", "subjectView");
    var incomePieSegment = dc.pieChart("#income-pie-segment", "subjectView");*/
    var chart3 = dc.barChart("#company-bar", "subjectView");
    var chart4 = dc.barChart("#days-bar", "subjectView");
    //var chart5 = dc.barChart("#stack-bar", "subjectView2");
	var chart5 = dc.compositeChart("#stack-bar", "subjectView2");
   
/*
    var numberChart1 = dc.numberDisplay("#number-box1", "subjectView");

    var numberChart2 = dc.numberDisplay("#number-box2", "subjectView");
    var numberChart3 = dc.numberDisplay("#number-box3", "subjectView");
    var numberChart4 = dc.numberDisplay("#number-box4", "subjectView");
    var segmentRowChart = dc.rowChart("#segment-row-chart", "subjectView");
    var custProdHoldChart = dc.barChart("#cust-bar-chart", "subjectView");
*/

// tooltips for row chart
            var rowTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" +  d.key + "</span> : "  + d.value; });

          // tooltips for bar chart
            var barTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" + d.data.key + "</span> : " + d.data.value ; });
         
          // tooltips for bar chart
            var lineTip = d3.tip()
                  .attr('class', 'd3-tip')
                  .offset([-10, 0])
                  .html(function (d) { return "<span style='color: #1AB394'>" + d.data.key + "</span> : " + d.data.value ; });
         




         chart1
            //.width(350)
            .height(220)
            .margins({top: 10, right: 40, bottom: 30, left: 20})
            .transitionDuration(1000)
            .dimension(deptDim)
            .gap(10)
            .group(deptGroup)
            //.ordinalColors(["#a8cf38","#c12026","#00aef5","#8781bd","#fbaf5d"])
            .ordering(function(d) { return -d.key })
            .label(function(d){
                return d.key + " : " + d.value ;
            })
            .elasticX(true)
            .xAxis().ticks(6).tickFormat(d3.format("s"));


        chart3
            .height(220)
            .margins({top: 10, right: 30, bottom: 70, left: 30})
            .transitionDuration(1000)
            .dimension(compDim)
            .group(compGroup)
            .centerBar(false)
            .gap(25)
            .elasticY(true)
            .x(d3.scale.ordinal().domain(compDim))
            .xUnits(dc.units.ordinal)
            .renderHorizontalGridLines(true)
            .renderVerticalGridLines(true)
            .ordering(function(d){return d.value;})
            
            .yAxis().tickFormat(d3.format("s"));

        chart4
            .height(220)
            .margins({top: 10, right: 30, bottom: 70, left: 30})
            .transitionDuration(1000)
            .dimension(daysoutDim)
            .group(daysGroup)
            .centerBar(false)
            .gap(25)
            .elasticY(true)
            .x(d3.scale.ordinal().domain(daysoutDim))
            .xUnits(dc.units.ordinal)
            .renderHorizontalGridLines(true)
            .renderVerticalGridLines(true)
            .ordering(function(d){return d.value;})            
            .yAxis().tickFormat(d3.format("s"));


        // changing the color of the Receivables Days Out barchart
        chart4
            .renderlet(function (chart) {
                //debugger;
                var colors = d3.scale.ordinal().domain(daysoutDim)
                    .range(["#a8cf38", "#F8EE00", "#ED7733", "#F12B25"]);
                chart4.selectAll('rect.bar').each(function (d) {
                    d3.select(this).attr("style", "fill: " + colors(d.data.key));
                });

            });

		/*
        chart5
            .margins({top: 20, right: 20, bottom: 20, left: 50})
            .height(220)
            .clipPadding(10)
            .transitionDuration(1000)
            .dimension(monthDim)
            .group(revenueGroup,"Revenue")
            .stack(expenseGroup,"Expense")
            .stack(cashGroup,"Cash")
            .centerBar(false)
            .gap(45)
            .elasticY(true)
            .renderHorizontalGridLines(true)
            .renderVerticalGridLines(true)
            .x(d3.scale.ordinal().domain(monthDim))
            .xUnits(dc.units.ordinal)
            .legend(dc.legend().x(60).y(1).itemHeight(7).gap(3));
		*/

        chart5
            .margins({top: 20, right: 20, bottom: 20, left: 50})
            .height(220)
            .clipPadding(10)
            .transitionDuration(500)
            .dimension(monthDim)
            .group(revenueGroup,"Revenue")            
            .elasticY(true)
            .renderHorizontalGridLines(true)
            .renderVerticalGridLines(true)
            .x(d3.scale.ordinal().domain(monthDim))			
            .xUnits(dc.units.ordinal)			
			.compose([
 				dc.barChart(chart5)
                .group(revenueGroup,"Revenue")
                .colors("#000000")
                .centerBar(true)				
                .gap(70),
				
                dc.barChart(chart5)
                .group(expenseGroup,"Expense")
                .colors("#FF0000")
                .centerBar(false)
                .gap(70),
				
                dc.lineChart(chart5)
                .group(cashGroup,"Cash")
                .renderDataPoints({radius: 3, fillOpacity: 0.8, strokeOpacity: 0.8})
                .colors("#7F7BE2")
            ])
			
            .legend(dc.legend().x(60).y(40).itemHeight(7).gap(3));


    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var order = months;
    var ordering = function(kv) {
        return order.indexOf(kv.key);
    };

    function sort_group(group, order) {
        return {
            all: function() {
                var g = group.all(), map = {};

                g.forEach(function(kv) {
                    map[kv.key] = kv.value;
                });
                return order.map(function(k) {
                    return {key: k, value: map[k]};
                });
            }
        };
    };

    chart2
        .height(220)
        .margins({top: 20, right: 20, bottom: 20, left: 50})
        .clipPadding(10)
        .dimension(month1Dim)
        .group(monthSalGroup)
        .transitionDuration(500)
        .elasticY(true)
        .renderHorizontalGridLines(true)
        .renderVerticalGridLines(true)
        .brushOn(false)
        .valueAccessor(function (d) {
            return d.value;
        })
        .x(d3.scale.ordinal().domain(month1Dim))
        .ordering(ordering)
        .xUnits(dc.units.ordinal)
        ._rangeBandPadding(1)
        .compose([
            dc.barChart(chart2)
                .group(sort_group(monthAvgGroup, order), "Average Expense")
                .colors("#2BBF9F")
                .centerBar(true)
                .gap(10),

            dc.lineChart(chart2)
                .group(sort_group(monthSalGroup, order), "Salary")
                .renderDataPoints({radius: 3, fillOpacity: 0.8, strokeOpacity: 0.8})
                .colors("#7F7BE2")
        ])
        .legend(dc.legend().x(55).y(0).itemHeight(8).gap(4));





            dc.renderAll("subjectView");
            dc.renderAll("subjectView2");
                      dc.renderAll("subjectView3");  

       d3.selectAll("g.row").call(rowTip);
        d3.selectAll("g.row").on('mouseover', rowTip.show)
            .on('mouseout', rowTip.hide);

       d3.selectAll(".dot").call(lineTip);
        d3.selectAll(".dot").on('mouseover', lineTip.show)
            .on('mouseout', lineTip.hide);

        d3.selectAll(".bar").call(barTip);
        d3.selectAll(".bar").on('mouseover', barTip.show)
            .on('mouseout', barTip.hide);
// rotate the x Axis labels

        chart3.selectAll("g.x text")
            .attr("class", "campusLabel")
            .style("text-anchor", "end") 
            .attr("transform", "translate(-10,0)rotate(315)");


};
